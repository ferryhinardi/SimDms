﻿var widget;
var transactionStatus;
var variables = {};

$(document).ready(function () {
    variables["DeleteAchievementStatus"] == false;

    var options = {
        title: "Service Information",
        xtype: "panels",
        toolbars: [
            { name: "btnSaveServiceID", text: "Save", icon: "icon-save" }
        ],
        panels: [
            {
                title: "Contact Information",
                items: [
                    {
                        text: "Employee",
                        type: "controls",
                        items: [
                            {
                                name: "EmployeeID", cls: "span2", placeHolder: "NIK", type: "popup-lookup", source: "ab.api/Grid/Employees", required: true, readonly: false,
                                columns: [
                                    { mData: "EmployeeID", sTitle: "NIK", sWidth: "80px" },
                                    { mData: "EmployeeName", sTitle: "Name", sWidth: "250px" },
                                    {
                                        mData: "Department", sTitle: "Department", sWidth: "100px"
                                    },
                                    { mData: "Position", sTitle: "Position", sWidth: "100px" },
                                    {
                                        mData: "JoinDate", sTitle: "Join Date", sWidth: "100px",
                                        mRender: function (prefix, value, fullData) {
                                            return widget.toDateFormat(widget.cleanJsonDate(fullData.JoinDate));
                                        }
                                    },
                                    {
                                        mData: "ResignDate", sTitle: "Resign Date", sWidth: "100px",
                                        mRender: function (prefix, value, fullData) {
                                            if (widget.isNullOrEmpty(fullData.ResignDate) == false) {
                                                return widget.toDateFormat(widget.cleanJsonDate(fullData.ResignDate));
                                            }
                                            else {
                                                return "-";
                                            }
                                        }
                                    },
                                    { mData: "Status", sTitle: "Status", sWidth: "100px" }
                                ],
                                additionalParams: [
                                    { name: "Department", value: "SERVICE" }
                                ]
                            },
                            { name: "EmployeeName", cls: "span6 ignore-uppercase", placeHolder: "Name", required: true, readonly: true }
                        ]
                    },
                    //{ text: "ATPM ID", cls: "span4", readonly: true, type: "popup", icon: "icon-bolt", hint: "clik here to get ATPM ID", name: "ServiceID" },
                    { name: "ServiceID", text: "Service ID", placeholder: "Service ID", cls: "span4" },
                    { text: "Email", cls: "span4", name: "Email", readonly: true },
                    { text: "Handphone 1", cls: "span4", name: "Handphone1", readonly: true },
                    { text: "Handphone 2", cls: "span4", name: "Handphone2", readonly: true },
                    { text: "Office Location", type: "textarea", name: "OfficeLocation", readonly: true },
                ]
            },
            {
                title: "Job Information",
                items: [
                    { text: "Join Date", cls: "span4", name: "JoinDate", readonly: true },
                    { text: "Resign Date", cls: "span4", name: "ResignDate", readonly: true },
                    { text: "Department", cls: "span4", name: "DepartmentName", readonly: true },
                    { text: "Position", cls: "span4", name: "PositionName", readonly: true },
                    { text: "GradeName", cls: "span4", name: "GradeName", readonly: true },
                    { text: "Rank", cls: "span4", name: "RankName", readonly: true },
                    { text: "Manager", cls: "span4", name: "TeamLeaderName", readonly: true },
                    { text: "Additional Job 1", cls: "span4", name: "AdditionalJob1Name", readonly: true },
                    { text: "Additional Job 2", cls: "span4", name: "AdditionalJob2Name", readonly: true },
                    { text: "Personal Status", cls: "span4", name: "Status", readonly: true },
                ]
            },
            {
                xtype: "tabs",
                name: "tabHrEmployeeSales",
                items: [
                    { name: "tabEmployeeAchievement", text: "Change Grade / Promotion" },
                    { name: "tabSalesTraining", text: "Sales Training" },
                ]
            },
            {
                title: "Data",
                cls: "tabHrEmployeeSales tabSalesTraining",
                xtype: "grid",
                name: "tblTrainingHistory",
                pnlname: "pnlTrainingHistory",
                source: "ab.api/Training/List",
                buttons: [
                    { name: "btnAddTraining", text: "Add Training", cls: "", icon: "icon-plus" }
                ],
                formName: "formTraining",
                selectable: true,
                multiselect: false,
                editButton: true,
                deleteButton: true,
                editAction: function (evt, data) {
                },
                deleteAction: function (evt, data) {
                    deleteTraining(evt, data);
                },
                sortings: [[1, "asc"]],
                items: [
                    {
                        text: "Training",
                        type: "controls",
                        items: [
                            { name: "TrainingDate", cls: "span2", placeholder: "Training Date", type: "datepicker", readonly: false },
                            { type: "select", name: "TrainingCode", cls: "span4", text: "Training", required: true },
                        ]
                    },
                    {
                        text: "Position",
                        type: "controls",
                        items: [
                            { name: "DepartmentTraining", cls:"span2", placeholder: "Department", readonly: true },
                            { name: "PositionTraining", cls: "span2", placeholder: "Position", readonly: true },
                            { name: "GradeTraining", cls: "span2", placeholder: "Grade", readonly: true },
                        ]
                    },
                    {
                        text: "Pre Test",
                        type: "controls",
                        items: [
                            { name: "PreTest", cls: "span2", placeholder: "Pre Test", readonly: false },
                            { name: "PreTestAlt", cls: "span4", placeholder: "Pre Test Alternative", readonly: false, type: "select" },
                        ]
                    },
                    {
                        text: "Post Test",
                        type: "controls",
                        items: [
                            { name: "PostTest", cls: "span2", placeholder: "Post Test", readonly: false },
                            { name: "PostTestAlt", cls: "span4", placeholder: "Post Test Alternative", readonly: false, type: "select" },
                        ]
                    },
                    { type: "buttons", items: [{ name: "btnSaveTraining", text: "Save", icon: "icon-save" }, { name: "btnCancelTraining", text: "cancel", icon: "icon-undo" }] },
                ],
                columns: [
                    {
                        sTitle: "Action",
                        "mDataProp": "",
                        "sClass": "",
                        "sDefaultContent": "</i><i class='icon icon-trash'></i>",
                        sWidth: "100px"
                    },
                    { mData: "EmployeeID", sTitle: "NIK", sWidth: "100px" },
                    { mData: "EmployeeName", sTitle: "Name", sWidth: "200px" },
                    { mData: "TrainingName", sTitle: "Training Name", sWidth: "150px" },
                    {
                        mData: "TrainingDate", sTitle: "Training Date", sWidth: "100px",
                        mRender: function (data, type, full) {
                            if (widget.isNullOrEmpty(data) == false) {
                                return widget.toDateFormat(widget.cleanJsonDate(data));
                            }
                            return "-";
                        }
                    },
                    { mData: "PreTest", sTitle: "Pre", sWidth: "50px" },
                    { mData: "PostTest", sTitle: "Post", sWidth: "50px" },
                ],
                additionalParams: [
                    { name: "EmployeeID", element: "EmployeeID" },
                ],
            },
            {
                title: "Data",
                cls: "tabHrEmployeeSales tabEmployeeAchievement",
                xtype: "grid",
                name: "tblEmployeeAchievement",
                pnlname: "pnlEmployeeAchievement",
                source: "ab.api/Achievement/List",
                buttons: [
                    { name: "btnAddAchievement", text: "Add Achievement", cls: "", icon: "icon-plus" }
                ],
                formName: "formAchievement",
                selectable: true,
                multiselect: false,
                editButton: true,
                deleteButton: true,
                editAction: function (evt, data) {
                },
                deleteAction: function (evt, data) {
                    deleteAchievement(evt, data);
                },
                sortings: [[1, "asc"]],
                items: [
                    {
                        text: "Department/Position",
                        type: "controls",
                        items: [
                            { type: "select", name: "DepartmentAchievement", cls: "span2", text: "Department", required: true },
                            { type: "select", name: "PositionAchievement", cls: "span2", text: "Position", required: true },
                            { type: "select", name: "GradeAchievement", cls: "span2", text: "Grade", required: false },
                        ]
                    },
                    { text: "Is Join Date", type: "switch", name: "IsJoinDate", cls: "span2 full", text: "is Join Date", float: "left" },
                    {
                        text: "Assign Date",
                        type: "controls",
                        items: [
                            { type: "datepicker", name: "AssignDate", cls: "span2", text: "Assign Date", required: true },
                        ]
                    },
                    { type: "buttons", items: [{ name: "btnSaveAchievement", text: "Save", icon: "icon-save" }, { name: "btnCancelAchievement", text: "cancel", icon: "icon-undo" }] },
                ],
                columns: [
                    {
                        sTitle: "Action",
                        "mDataProp": "",
                        "sClass": "",
                        "sDefaultContent": "</i><i class='icon icon-trash'></i>",
                        sWidth: "100px"
                    },
                    { mData: "EmployeeID", sTitle: "NIK", sWidth: "100px" },
                    { mData: "EmployeeName", sTitle: "Name", sWidth: "200px" },
                    { mData: "DepartmentName", sTitle: "Department", sWidth: "80px" },
                    { mData: "PositionName", sTitle: "Position", sWidth: "200px" },
                    { mData: "GradeName", sTitle: "Grade", sWidth: "100px" },
                    {
                        mData: "AssignDate", sTitle: "Assign Date", sWidth: "100px",
                        mRender: function (data, type, full) {
                            if (widget.isNullOrEmpty(data) == false) {
                                return widget.toDateFormat(widget.cleanJsonDate(data));
                            }
                            return "-";
                        }
                    },
                    { mData: "AssignDateStatus", sTitle: "Status", sWidth: "100px" },
                ],
                additionalParams: [
                    { name: "EmployeeID", element: "EmployeeID" }
                ],
            },
        ],
    }

    transactionStatus = false;
    widget = new SimDms.Widget(options);
    widget.lookup.onDblClick(function (e, data, name) {
        lookupOnDblClick(e, data, name);
    });
    var paramsEvent = [
        {
            name: "EmployeeID",
            type: "input",
            eventType: "blur",
            event: function (evt) {
                findEmployee();
            }
        },
        {
            name: "TrainingDate",
            type: "input",
            eventType: "change",
            event: function (evt) {
                var url = "ab.api/Training/TrainingList";
                var params = {
                    EmployeeID: $("[name='EmployeeID']").val(),
                    TrainingDate: $("[name='TrainingDate']").val()
                };

                widget.post(url, params, function (result) {
                    if (widget.isNullOrEmpty(result.status)) {
                        widget.setItems({
                            name: "TrainingCode",
                            type: "select",
                            data: result
                        });

                        url = "ab.api/Employee/GetDetailsEmployeePosition";
                        params = {
                            EmployeeID: $("[name='EmployeeID']").val(),
                            AssignDate: $("[name='TrainingDate']").val()
                        };

                        widget.post(url, params, function (result) {
                            if (widget.isNullOrEmpty(result.data) == false) {
                                $("[name='DepartmentTraining']").val(result.data.Department);
                                $("[name='PositionTraining']").val(result.data.Position);
                                $("[name='GradeTraining']").val(result.data.Grade);
                            }
                        });
                    }
                    else {
                        $("[name='TrainingDate']").val('');
                        alert(result.message);
                    }
                });
            }
        },
        {
            name: "btnAddAchievement",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnAddAchievement(evt);
            }
        },
        {
            name: "btnSaveAchievement",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnSaveAchievement(evt);
            }
        },
        {
            name: "btnCancelAchievement",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnCancelAchievement(evt);
            }
        },
        {
            name: "btnSaveServiceID",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnServiceID(evt);
            }
        },
        {
            name: "btnClear",
            type: "button",
            eventType: "click",
            event: function (evt) {
                clearForm(evt);
            }
        },
        {
            name: "btnAddTraining",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnAddTraining(evt);
            }
        },
        {
            name: "PositionTraining",
            type: "select",
            eventType: "change",
            event: function (evt) {
                var currentVal = widget.getValue({ name: "PositionTraining", type: "select" });
                var gradeElement = widget.getObject("GradeTraining", "select");
                if (currentVal == "S") {
                    gradeElement.attr("required", "required");
                }
                else {
                    gradeElement.removeAttr("required");
                    gradeElement.removeClass("error");
                    gradeElement.parent().children("label").parent().remove();
                }
            }
        },
        {
            name: "btnSaveTraining",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnSaveTraining(evt);
            }
        }, 
        {
            name: "btnCancelTraining",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnCancelTraining(evt);
            }
        },
        {
            name: "PositionAchievement",
            type: "select",
            eventType: "change",
            event: function (evt) {
                var currentVal = widget.getValue({ name: "PositionAchievement", type: "select" });
                var gradeElement = widget.getObject("GradeAchievement", "select");
                if (currentVal == "S") {
                    gradeElement.attr("required", "required");
                    widget.showInputElement({
                        name: "GradeAchievement",
                        type: "select",
                        visible: true,
                        type: "controls"
                    });
                }
                else {
                    widget.showInputElement({
                        name: "GradeAchievement",
                        type: "select",
                        visible: false,
                        type: "controls"
                    });
                    gradeElement.removeAttr("required");
                    gradeElement.removeClass("error");
                    gradeElement.parent().children("label").remove();
                }
            }
        },
    ];
    widget.setEventList(paramsEvent);

    var paramsSelect = [
        {
            name: "PreTestAlt", url: "ab.api/Combo/TrainingPreScoresAlternative"
        },
        {
            name: "PostTestAlt", url: "ab.api/Combo/TrainingPostScoresAlternative"
        },
        {
            name: "DepartmentAchievement", url: "ab.api/Combo/Departments",
        },
        {
            name: "PositionAchievement", url: "ab.api/Combo/Positions",
            cascade: {
                name: "DepartmentAchievement",
            }
        },
        {
            name: "GradeTraining", url: "ab.api/Combo/Grades",
            cascade: {
                name: "PositionTraining",
                additionalParams: [],
                conditions: [
                    { name: "PositionTraining", condition: "=='S'" }
                ]
            }
        },
        {
            name: "GradeAchievement", url: "ab.api/Combo/Grades",
            cascade: {
                name: "PositionAchievement",
                additionalParams: [],
                conditions: [
                    { name: "PositionAchievement", condition: "=='S'" }
                ]
            }
        },
        {
            name: "TrainingCode", url: "ab.api/Training/TrainingList",
            cascade: {
                name: "PositionTraining",
                additionalParams: [
                    { name: "EmployeeID", source: "EmployeeID", type: "input" },
                    { name: "Department", source: "DepartmentTraining", type: "select" },
                    { name: "Position", source: "PositionTraining", type: "select" },
                    { name: "Grade", source: "GradeTraining", type: "select" },
                ]
            }
        },
        {
            name: "TrainingCode", url: "ab.api/Training/TrainingList",
            cascade: {
                name: "GradeTraining",
                additionalParams: [
                    { name: "EmployeeID", source: "EmployeeID", type: "input" },
                    { name: "Department", source: "DepartmentTraining", type: "select" },
                    { name: "Position", source: "PositionTraining", type: "select" },
                    { name: "Grade", source: "GradeTraining", type: "select" },
                ]
            }
        },
    ];
    widget.setSelect(paramsSelect);

    widget.render();
});





function lookupOnDblClick(e, data, name) {
    clearForm();

    if (widget.isNullOrEmpty(data.JoinDate) == false) {
        try {
            data["JoinDate"] = widget.toDateFormat(widget.cleanJsonDate(data.JoinDate));
            data["ResignDate"] = widget.toDateFormat(widget.cleanJsonDate(data.ResignDate));
        } catch (ex) { }
    }
    widget.populate(data, populateCallback(e, data, name));
    widget.lookup.hide();                  
    transactionStatus = true;

    //reloadTrainingData();
    //reloadAchievementData();
}

function populateCallback(e, data, name) {
    var btnSalesIDStatus = false;
    if (widget.isNullOrEmpty(data.ServiceID) == false) {
        //btnSalesIDStatus = false;
        widget.enableElement([{ name: "ServiceID", type: "input", status: false }]);
    }
    else {
        //btnSalesIDStatus = true;
        widget.enableElement([{ name: "ServiceID", type: "input", status: true }]);
    }
    //widget.enableElement([{ name: "btnServiceID", type: "button", status: btnSalesIDStatus }]);

    //widget.selects({
    //    name: "DepartmentTraining",
    //    source: "ab.api/Training/DepartmentList",
    //    additionalParams: [
    //        { name: "EmployeeID", element: "EmployeeID", type: "input", value: data.EmployeeID }
    //    ]
    //});

    widget.selects({
        name: "DepartmentAchievement",
        source: "ab.api/Combo/Departments",
        additionalParams: [
            { name: "EmployeeID", element: "EmployeeID", type: "input", value: data.EmployeeID }
        ]
    });

    reloadTrainingData();
    reloadAchievementData();
}

function evt_btnServiceID(evt) {
    if (transactionStatus && widget.isNullOrEmpty($("[name='EmployeeID']").val()) == false && widget.isNullOrEmpty($("[name='ServiceID']").val()) == false) {
        var params = {
            EmployeeID: widget.getValue({ name: "EmployeeID", type: "text" }),
            ServiceID: $("[name=ServiceID]").val()
        };

        var url = "ab.api/Employee/SaveServiceID";

        widget.post(url, params, function (result) {
            if (result.status) {
                var serviceIDElement = widget.getObject("ServiceID");
                //serviceIDElement.val(result.atpmID);
                widget.enableElement([{ name: "ServiceID", type: "input", status: false }]);
                widget.enableElement([
                    { name: "btnServiceID", type: "button", status: false }
                ]);
            }
            else {
                alert(result.message || "Error occured.");
            }
        });
    }
    else {
        alert("Choose one Employee and fill Service ID first.");
    }
}

function clearForm(evt) {
    transactionStatus = false;
    widget.enableElement([{ name: "ServiceID", type: "button", status: true }]);
    widget.clearForm();

    widget.reloadGridData("tblTrainingHistory");
    $("#pnlTrainingHistory").hide();
    $("#btnAddTraining").show();
    widget.reloadGridData("tblEmployeeAchievement");
    $("#pnlEmployeeAchievement").hide();
    $("#btnAddAchievement").show();
    $("[name='AssignDate']").removeAttr("disabled");
}

function findEmployee() {
    var url = "ab.api/Employee/Find";
    var params = {
        employeeID: widget.getValue({ name: "EmployeeID", type: "text" })
    };

    widget.post(url, params, function (result) {
        if (widget.isNullOrEmpty(result.data) == false) {
            if (widget.isNullOrEmpty(result.data.JoinDate) == false) {
                try {
                    result.data["JoinDate"] = widget.toDateFormat(widget.cleanJsonDate(result.data.JoinDate));
                    result.data["ResignDate"] = widget.toDateFormat(widget.cleanJsonDate(result.data.ResignDate));
                } catch (ex) { }
            }

            widget.populate(result.data, populateCallback(null, result.data, null));
        }
        else {
            var employeeID = $("[name='EmployeeID']").val();
            clearForm();
            $("[name='EmployeeID']").val(employeeID);
        }
    });
}





function evt_btnAddTraining(evt) {
    if (transactionStatus) {
        $("[name='btnAddTraining']").hide();
        $("#pnlTrainingHistory").slideDown();
    }
}

function evt_btnSaveTraining(evt) {
    if (transactionStatus) {
        //if (transactionStatus && widget.validate("formTraining")) {
        var params = widget.getForms("formTraining");
        params["EmployeeID"] = widget.getValue({ name: "EmployeeID", type: "input" });
        params["TrainingCode"] = widget.getValue({ name: "TrainingCode", type: "select" });
        params["TrainingDate"] = widget.getValue({ name: "TrainingDate", type: "input" });
        params["PreTest"] = widget.getValue({ name: "PreTest", type: "input" });
        params["PreTestAlt"] = widget.getValue({ name: "PreTestAlt", type: "input" });
        params["PostTest"] = widget.getValue({ name: "PostTest", type: "input" });
        params["PostTestAlt"] = widget.getValue({ name: "PostTestAlt", type: "input" });
        

        var url = "ab.api/Training/Save";
        widget.post(url, params, function (result) {
            if (result.status) {
                $("[name='btnAddTraining']").show();
                $("#pnlTrainingHistory").slideUp();
                widget.clearForm("formTraining");
                reloadTrainingData();
            }
            else {
                alert(result.message);
            }
        });
    }
}

function evt_btnCancelTraining(evt) {
    $("[name='btnAddTraining']").show();
    $("#pnlTrainingHistory").slideUp();
    widget.clearForm("formTraining");
    widget.clearValidation("formTraining");
}

function reloadTrainingData() {
    setTimeout(function () {
        widget.reloadGridData("tblTrainingHistory");
    }, 1000);
}

function saveTraining(evt) {
    if (transactionStatus && widget.validate("formTraining")) {
        var params = widget.getForms("formTraining");
        params["EmployeeID"] = widget.getValue({ name: "EmployeeID", type: "input" });
        var url = "ab.api/Training/Save";
        widget.post(url, params, function (result) {
            if (result.status) {
                $("[name='btnAddTraining']").show();
                $("#pnlTrainingHistory").slideUp();
                widget.clearForm("formTraining");
                reloadTrainingData();
            }
            else {
                alert(result.message);
            }
        });
    }
}

function deleteTraining(evt, data) {
    if (confirm("Do you want to delete this data ?")) {
        var params = {
            EmployeeID: data.EmployeeID,
            TrainingDate: widget.toDateFormat(widget.cleanJsonDate(data.TrainingDate))
        };
        var url = "ab.api/Training/Delete";
        widget.post(url, params, function (result) {
            reloadTrainingData();
            clearForm();
        });
    }
}



function validateJoinDateEmployeeAchievement(hideAddAchievement) {
    var url = "ab.api/Employee/CheckJoinDate";
    var params = { EmployeeID: $("#EmployeeID").val() };

    widget.post(url, params, function (result) {
        var panelAchievementVisibility = $("#pnlEmployeeAchievement").css("display");

        if (panelAchievementVisibility != "none") {
            $("[name='btnAddAchievement']").hide();
        }
        else {
            $("[name='btnAddAchievement']").show();
        }

        widget.changeSwitchValue({
            panel: "pnlEmployeeAchievement",
            name: "IsJoinDate",
            value: false
        });

        if (widget.isNullOrEmpty(result.data) == false) {
            if (widget.isNullOrEmpty(result.data.HasJoinDateInAchievement) == false) {
                var panelJoinDate = $("#IsJoinDateN").parent().parent().parent();
                if (result.data.HasJoinDateInAchievement == true) {
                    panelJoinDate.hide();
                }
                else {
                    panelJoinDate.show();
                }
            }
            else {
                $("#IsJoinDateN").parent("div").show();
            }

            variables["DeleteAchievementStatus"] == false;
                                        
            $("#IsJoinDateN, #IsJoinDateY").on("click" ,function (event) {
                var _this = this;
                setTimeout(function () {
                    $("[name='AssignDate']").attr("disabled", true);
                    var isJoinDate = $(_this).attr("value");

                    if ($(_this).attr("value") == "true") {
                        if (widget.isNullOrEmpty(result.data.JoinDate) == false) {
                            $("[name='AssignDate']").val(widget.toDateFormat(widget.cleanJsonDate(result.data.JoinDate)));
                        }
                    }
                    else {
                        $("[name='AssignDate']").val('');
                        $("[name='AssignDate']").removeAttr("disabled");
                    }
                }, 250);
            });      
        }
    });
}

function evt_btnAddAchievement(evt) {
    if (transactionStatus) {
        $("#pnlEmployeeAchievement").slideDown();
        widget.showInputElement({
            name: "GradeAchievement",
            type: "select",
            visible: true
        });
        validateJoinDateEmployeeAchievement(true);
    }
}

function evt_btnSaveAchievement(evt) {
    if (transactionStatus && widget.validate("formAchievement")) {
        var params = widget.getForms("formAchievement");
        params["EmployeeID"] = widget.getValue({ name: "EmployeeID", type: "input" });
        var url = "ab.api/Achievement/Save";
        widget.post(url, params, function (result) {
            if (result.status) {
                $("[name='btnAddAchievement']").show();
                $("#pnlEmployeeAchievement").slideUp();
                widget.clearForm("formAchievement");
                updateEmployeeForm(params["EmployeeID"]);
                reloadAchievementData();
                $("[name='AssignDate']").removeAttr("disabled");
                $("[name='AssignDate']").val('');
            }
            else {
                alert(result.message);
            }
        });
    }
}

function evt_btnCancelAchievement(evt) {
    $("[name='btnAddAchievement']").show();
    $("#pnlEmployeeAchievement").slideUp();
    widget.clearForm("formAchievement");
    widget.clearValidation("formAchievement");
    $("[name='AssignDate']").val('');
    $("[name='AssignDate']").removeAttr("disabled");
}

function reloadAchievementData() {
    setTimeout(function () {
        widget.reloadGridData("tblEmployeeAchievement");
    }, 1000);
}

function deleteAchievement(evt, data) {
    if (confirm("Do you want to delete this data ?")) {
        variables["DeleteAchievementStatus"] = false;
        var params = $.extend(data, {
            AssignDate: widget.toDateFormat(widget.cleanJsonDate(data.AssignDate))
        });

        var url = "ab.api/Achievement/Delete";
        widget.post(url, params, function (result) {
            if (result.status) {
                //clearForm();
                reloadAchievementData();
                updateEmployeeForm(data.EmployeeID);
                variables["DeleteAchievementStatus"] == true;
                validateJoinDateEmployeeAchievement(true);
            }
            else {
                alert(result.message);
            }
            $("[name='btnAddAchievement']").show();
        });
    }
}

function updateEmployeeForm(employeeID) {
    var url = "ab.api/Achievement/UpdatedAchievement";
    var params = {
        EmployeeID: employeeID
    };

    widget.post(url, params, function (result) {
        if (result.status) {
            result.data["JoinDate"] = widget.toDateFormat(widget.cleanJsonDate(result.data.JoinDate));
            widget.populate(result.data);
        }
    });
}


﻿var widget;
var transactionStatus = false;
var variables = {};

$(document).ready(function () {
    var options = {
        title: "Personal Information",
        xtype: "panels",
        toolbars: [
            { name: "btnClear", text: "New", icon: "icon-file" },
            { name: "btnSave", text: "Save", icon: "icon-save", cls: "" },
            { name: "btnBrowse", text: "Browse", icon: "icon-search" },
        ],
        panels: [
            {
                title: "Contact Information",
                name: "contactInformation",
                items: [
                    {
                        text: "Employee",
                        type: "controls",
                        items: [
                            {
                                name: "EmployeeID", cls: "span2", placeHolder: "NIK", type: "popup-lookup", source: "ab.api/Grid/Employees", required: false, maxlength: 20, 
                                columns: [
                                    { mData: "EmployeeID", sTitle: "NIK", sWidth: "80px" },
                                    { mData: "EmployeeName", sTitle: "Name", sWidth: "250px", maxlength: 20, },
                                    {
                                        mData: "Department", sTitle: "Department", sWidth: "100px"
                                    },
                                    { mData: "Position", sTitle: "Position", sWidth: "100px" },
                                    {
                                        mData: "JoinDate", sTitle: "Join Date", sWidth: "100px",
                                        mRender: function (prefix, value, fullData) {
                                            return widget.toDateFormat(widget.cleanJsonDate(fullData.JoinDate));
                                        }
                                    },
                                    {
                                        mData: "ResignDate", sTitle: "Resign Date", sWidth: "100px",
                                        mRender: function (prefix, value, fullData) {
                                            if (widget.isNullOrEmpty(fullData.ResignDate) == false) {
                                                return widget.toDateFormat(widget.cleanJsonDate(fullData.ResignDate));
                                            }
                                            else {
                                                return "-";
                                            }
                                        }
                                    },
                                    { mData: "Status", sTitle: "Status", sWidth: "100px" }
                                ]
                            },
                            { name: "EmployeeName", cls: "span6 ignore-uppercase", placeHolder: "Name", required: false }
                        ]
                    },
                    { name: "Email", text: "Email", cls: "span4 ignore-uppercase", maxlength: 50},
                    { name: "FaxNo", text: "Fax No", cls: "span4", maxlength: 50 },
                    { name: "Handphone1", text: "Handphone 1", cls: "span4", required: true },
                    { name: "Telephone1", text: "Telephone 1", cls: "span4", maxlength: 50 },
                    { name: "Handphone2", text: "Handphone 2", cls: "span4", maxlength: 50 },
                    { name: "Telephone2", text: "Telephone 2", cls: "span4", maxlength: 50 },
                    { name: "Handphone3", text: "Handphone 3", cls: "span4 full", maxlength: 50 },
                    { name: "Handphone4", text: "PIN BB / WU", cls: "span4", maxlength: 50 },
                    { name: "OfficeLocation", text: "Office Location", type: "textarea", required: false, maxlength: 250 },
                    {
                        text: "User ID",
                        type: "controls",
                        items: [
                            {
                                name: "RelatedUser", text: "User ID", cls: "span2", placeHolder: "User ID", maxlength: 25, type: "popup-lookup",
                                readonly: true,
                                maxlength: 20,
                                source: "ab.api/Grid/Users",
                                title: "User List",
                                columns: [
                                    { mData: "RelatedUser", sTitle: "User ID", sWidth: "200px" },
                                    { mData: "FullName", sTitle: "Full Name", sWidth: "500px" }
                                ]
                            },
                            { name: "FullName", text: "Full Name", cls: "span6", placeHolder: "Full Name", readonly: true }
                        ]
                    },
                ]
            },
            {
                title: "Job Information",
                items: [
                    { name: "JoinBranch", text: "Join Branch", cls: "span4", type: "select", url: "", dataSource: "ab.api/Combo/Branch", required: true },
                    { name: "JoinDate", text: "Join Date", cls: "span4", type: "datepicker", required: true },
                    { name: "Department", text: "Department", cls: "span4", type: "select", url: "", dataSource: "ab.api/Combo/Departments", required: true },
                    { name: "Position", text: "Position", cls: "span4", type: "select", required: true },
                    { name: "Grade", text: "Grade", cls: "span4", type: "select" },
                    { name: "TeamLeader", text: "Direct Leader", cls: "span4", type: "select" },
                    { name: "Rank", text: "Rank", cls: "span4", type: "select", dataSource: "ab.api/Combo/Ranks", required: false },
                    { name: "AdditionalJob1", text: "Additional Job 1", cls: "span4", type: "select" },
                    { name: "AdditionalJob2", text: "Additional Job 2", cls: "span4", type: "select" },
                    { name: "PersonnelStatus", text: "Personnel Status", cls: "span4", type: "select", dataSource: "ab.api/Combo/PersonnelStatus", required: true },
                    { name: "ResignDate", text: "Resign Date", cls: "span4", type: "datepicker" },
                    { name: "ResignCategory", text: "Resign Category", cls: "span4", type: "select" },
                    { name: "ResignDescription", text: "Resign Description", type: "textarea", maxlength: 500 },
                ]
            },
            {
                title: "Detail Information",
                items: [
                    { name: "IdentityNo", text: "Identity No", cls: "span4", required: true, maxlength: 80 },
                    { name: "NPWPNo", text: "NPWP No", cls: "span4", required: true, maxlength: 50 },
                    { name: "NPWPDate", text: "NPWP Date", cls: "span4", type: "datepicker", required: true },
                    { name: "BirthDate", text: "Birth Date", cls: "span4", type: "datepicker", required: true },
                    { name: "BirthPlace", text: "Birth Place", cls: "span4", required: true },
                    { name: "Address1", text: "Address", required: true },
                    { name: "Address2", text: "" },
                    { name: "Address3", text: "" },
                    { name: "Address4", text: "" },
                    { name: "Province", text: "Province", cls: "span4", type: "select", dataSource: "ab.api/Combo/Provinces", required: false },
                    { name: "District", text: "District", cls: "span4", type: "select", required: false },
                    { name: "SubDistrict", text: "Sub Distric", cls: "span4", type: "select", required: false },
                    { name: "Village", text: "Village", cls: "span4", type: "select", required: false },
                    { name: "ZipCode", text: "Zip Code", cls: "span4", required: true, maxlength: 10 },
                    { name: "Gender", text: "Gender", cls: "span4", type: "select", dataSource: "ab.api/Combo/Genders", required: true },
                    { name: "Religion", text: "Religion", cls: "span4", type: "select", dataSource: "ab.api/Combo/Religions", required: true },
                ]
            },
            {
                title: "Other Information",
                items: [
                    { name: "DrivingLicense1", text: "Driving License 1", cls: "span4", maxlength: 50 },
                    { name: "DrivingLicense2", text: "Driving License 2", cls: "span4", maxlength: 50 },
                    { name: "MaritalStatus", text: "Marital Status", cls: "span4", type: "select", dataSource: "ab.api/Combo", required: true },
                    { name: "MaritalStatusCode", text: "Marital Status Details", cls: "span4", type: "select" },
                    { name: "Height", text: "Height", cls: "span4", maxlength: 5 },
                    { name: "Weight", text: "Weight", cls: "span4", maxlength: 5 },
                    { name: "UniformSize", text: "Uniform Size", cls: "span4", type: "select", dataSource: "ab.api/Combo/UniformSizes", required: true },
                    { name: "UniformSizeAlt", text: "Uniform Size Alt", cls: "span4", type: "select", dataSource: "ab.api/Combo/UniformSizeAlts", required: true },
                    { name: "ShoesSize", text: "Shoes Size", cls: "span4", type: "select", dataSource: "ab.api/Combo/ShoesSize" },
                    { name: "BloodCode", text: "Blood Code", cls: "span4", type: "select", dataSource: "ab.api/Combo/BloodTypes" },
                    { name: "FormalEducation", text: "Formal Education", cls: "span4", type: "select", dataSource: "ab.api/Combo/FormalEducations", required: true },
                    { name: "OtherInformation", text: "Other Information", type: "textarea", maxlength: 500 },
                ]
            },
            {
                xtype: "tabs",
                name: "tabPersonnel",
                items: [
                    { name: "tabPhotos", text: "Photos" },
                    { name: "tabSubordinate", text: "Subordinates" },
                    { name: "tabEmployeeAchievement", text: "Employee Achievement" },
                    { name: "tabTrainingHistory", text: "Training History" },
                    { name: "tabVehicle", text: "Vehicle Ownership" }, 
                ]
            },
            {
                title: "Employee",
                cls: "tabPersonnel tabPhotos",
                items: [
                    {
                        name: "SelfPhoto", type: "image", cls: "span4", events: [
                            {
                                eventType: "click",
                                event: function (evt) {
                                    evt_SelfPhotoClick(evt);
                                }
                            }
                        ],
                        size: [125, 150],
                        margins: {
                            left: -70
                        },
                        src: SimDms.baseUrl + "assets/img/employee/person.png"
                    },
                    {
                        name: "IdentityCardPhoto", type: "image", cls: "span4", events: [
                            {
                                eventType: "click",
                                event: function (evt) {
                                    evt_IdentityCardPhotoClick(evt);
                                }
                            }
                        ],
                        size: [290, 150],
                        src: SimDms.baseUrl + "assets/img/employee/ktp.png",
                        margins: {
                            left: -460
                        },
                    },
                ]
            },
            {
                title: "Data",
                cls: "tabPersonnel tabSubordinate",
                xtype: "grid",
                name: "tblSubordinate",
                pnlname: "pnlSubordinate",
                source: "ab.api/grid/Subordinates",
                selectable: true,
                multiselect: false,
                sortings: [[1, "asc"]],
                items: [],
                columns: [
                    { mData: "EmployeeID", sTitle: "NIK", sWidth: "100px" },
                    { mData: "EmployeeName", sTitle: "Name", sWidth: "250px" },
                    { mData: "Department", sTitle: "Department", sWidth: "100px" },
                    { mData: "Position", sTitle: "Position", sWidth: "100px" },
                    { mData: "Rank", sTitle: "Rank", sWidth: "100px" },
                ],
                additionalParams: [
                    { name: "TeamLeaderID", element: "EmployeeID" },
                    { name: "Department", element: "Department", type: "select" },
                ],
            },
            {
                title: "Data",
                cls: "tabPersonnel tabVehicle",
                xtype: "grid",
                name: "tblVehicle",
                pnlname: "pnlVehicle",
                source: "ab.api/Vehicle/List",
                buttons: [
                    { name: "btnAddVehicle", text: "Add Vehicle", cls: "", icon: "icon-plus" }
                ],
                formName: "formVehicle",
                selectable: true,
                multiselect: false,
                editButton: true,
                deleteButton: true,
                editAction: function (evt, data) {
                },
                deleteAction: function (evt, data) {
                    deleteVehicle(evt, data);
                },
                sortings: [[1, "asc"]],
                items: [
                    { name: "Type", text: "Type", cls: "span3", type: "text", required: true, maxlength: 20 },
                    {
                        name: "Brand", text: "Brand", cls: "span3", type: "select", required: true,
                        items: [
                            { value: "Daihatsu", text: "Daihatsu", required: true },
                            { value: "Honda", text: "Honda", required: true },
                            { value: "Nissan", text: "Nissan", required: true },
                            { value: "Suzuki", text: "Suzuki", required: true },
                            { value: "Toyota", text: "Toyota", required: true },
                        ]
                    },
                    { name: "Model", text: "Model", cls: "span3", type: "text", required: true, maxlength: 20 },
                    { name: "PoliceRegNo", text: "Police Reg. No.", cls: "span3", type: "text", required: true, maxlength: 20 },
                    {
                        type: "buttons", items: [
                            { name: "btnSaveVehicle", text: "Save", icon: "icon-save" },
                            { name: "btnCancelVehicle", text: "Cancel", icon: "icon-undo" }
                        ]
                    },
                ],
                columns: [
                    {
                        sTitle: "Action",
                        "mDataProp": "",
                        "sClass": "",
                        "sDefaultContent": "</i><i class='icon icon-trash'></i>",
                        sWidth: "50px"
                    },
                    { mData: "Type", sTitle: "Type", text: "Type", cls: "", width: 150 },
                    { mData: "Brand", sTitle: "Brand", text: "Brand", cls: "", width: 150 },
                    { mData: "Model", sTitle: "Model", text: "Model", cls: "", width: 150 },
                ],
                additionalParams: [
                    { name: "EmployeeID", element: "EmployeeID" }
                ],
            },
            //{
            //    title: "Data",
            //    cls: "tabPersonnel tabTrainingHistory",
            //    xtype: "grid",
            //    name: "tblTrainingHistory",
            //    pnlname: "pnlTrainingHistory",
            //    source: "ab.api/Training/List",
            //    buttons: [],
            //    formName: "formTraining",
            //    selectable: true,
            //    multiselect: false,
            //    editButton: true,
            //    deleteButton: true,
            //    editAction: function (evt, data) {

            //    },
            //    deleteAction: function (evt, data) {},
            //    sortings: [[1, "asc"]],
            //    items: [
            //        { type: "select", name: "DepartmentTraining", cls: "span5", text: "Department", required: true },
            //        { type: "select", name: "PositionTraining", cls: "span5", text: "Position", required: true },
            //        { type: "select", name: "GradeTraining", cls: "span5", text: "Grade", required: false },
            //        { type: "select", name: "TrainingCode", cls: "span5", text: "Training", required: true },
            //        { type: "datepicker", name: "TrainingDate", cls: "span5", text: "Training Date", required: true },
            //        { type: "text", name: "PreTest", cls: "span5", text: "Pre Test" },
            //        { type: "select", name: "PreTestAlt", cls: "span5", text: "Pre Test Alternative" },
            //        { type: "text", name: "PostTest", cls: "span5", text: "Post Test" },
            //        { type: "select", name: "PostTestAlt", cls: "span5", text: "Pos Test Alternative" },
            //        { type: "buttons", items: [{ name: "btnSaveTraining", text: "Save", icon: "icon-save" }, { name: "btnCancelTraining", text: "cancel", icon: "icon-undo" }] },
            //    ],
            //    columns: [
            //        { mData: "EmployeeID", sTitle: "NIK", sWidth: "100px" },
            //        { mData: "EmployeeName", sTitle: "Name", sWidth: "200px" },
            //        { mData: "TrainingName", sTitle: "Training Name", sWidth: "150px" },
            //        {
            //            mData: "TrainingDate", sTitle: "Training Date", sWidth: "100px",
            //            mRender: function (data, type, full) {
            //                if (widget.isNullOrEmpty(data) == false) {
            //                    return widget.toDateFormat(widget.cleanJsonDate(data));
            //                }
            //                return "-";
            //            }
            //        },
            //        { mData: "PreTest", sTitle: "Pre", sWidth: "50px" },
            //        { mData: "PostTest", sTitle: "Post", sWidth: "50px" },
            //    ],
            //    additionalParams: [
            //        { name: "EmployeeID", element: "EmployeeID"}
            //    ],
            //},
            {
                title: "Data",
                cls: "tabPersonnel tabEmployeeAchievement",
                xtype: "grid",
                name: "tblEmployeeAchievement",
                pnlname: "pnlEmployeeAchievement",
                source: "ab.api/Achievement/List",
                buttons: [
                    { name: "btnAddAchievement", text: "Add Achievement", cls: "", icon: "icon-plus" }
                ],
                formName: "formAchievement",
                selectable: true,
                multiselect: false,
                editButton: true,
                deleteButton: true,
                editAction: function (evt, data) {
                },
                deleteAction: function (evt, data) {
                    deleteAchievement(evt, data);
                },
                sortings: [[1, "asc"]],
                items: [
                    {
                        text: "Department/Position",
                        type: "controls",
                        items: [
                            { type: "select", name: "DepartmentAchievement", cls: "span2", text: "Department", required: true },
                            { type: "select", name: "PositionAchievement", cls: "span2", text: "Position", required: true },
                            { type: "select", name: "GradeAchievement", cls: "span2", text: "Grade", required: false },
                        ]
                    },
                    { text: "Is Join Date", type: "switch", name: "IsJoinDate", cls: "span2 full", text: "is Join Date", float: "left" },
                    {
                        text: "Assign Date",
                        type: "controls",
                        items: [
                            { type: "datepicker", name: "AssignDate", cls: "span2", text: "Assign Date", required: true },
                        ]
                    },
                    { type: "buttons", items: [{ name: "btnSaveAchievement", text: "Save", icon: "icon-save" }, { name: "btnCancelAchievement", text: "cancel", icon: "icon-undo" }] },
                ],
                columns: [
                    {
                        sTitle: "Action",
                        "mDataProp": "",
                        "sClass": "",
                        "sDefaultContent": "</i><i class='icon icon-trash'></i>",
                        sWidth: "80px"
                    },
                    { mData: "EmployeeID", sTitle: "NIK", sWidth: "100px" },
                    { mData: "EmployeeName", sTitle: "Name", sWidth: "180px" },
                    { mData: "DepartmentName", sTitle: "Department", sWidth: "80px" },
                    { mData: "PositionName", sTitle: "Position", sWidth: "250px" },
                    { mData: "GradeName", sTitle: "Grade", sWidth: "100px" },
                    {
                        mData: "AssignDate", sTitle: "Assign Date", sWidth: "120px",
                        mRender: function (data, type, full) {
                            if (widget.isNullOrEmpty(data) == false) {
                                return widget.toDateFormat(widget.cleanJsonDate(data));
                            }
                            return "-";
                        }
                    },
                    { mData: "AssignDateStatus", sTitle: "Status", sWidth: "100px" },
                ],
                additionalParams: [
                    { name: "EmployeeID", element: "EmployeeID" }
                ],
            },
            {
                title: "Data",
                cls: "tabPersonnel tabTrainingHistory",
                xtype: "grid",
                name: "tblTrainingHistory",
                pnlname: "pnlTrainingHistory",
                source: "ab.api/Training/List",
                buttons: [
                    { name: "btnAddTraining", text: "Add Training", cls: "", icon: "icon-plus" }
                ],
                formName: "formTraining",
                selectable: true,
                multiselect: false,
                editButton: true,
                deleteButton: true,
                editAction: function (evt, data) {
                },
                deleteAction: function (evt, data) {
                    deleteTraining(evt, data);
                },
                sortings: [[1, "asc"]],
                items: [
                    {
                        text: "Training",
                        type: "controls",
                        items: [
                            { name: "TrainingDate", cls: "span2", placeholder: "Training Date", type: "datepicker", readonly: false },
                            { type: "select", name: "TrainingCode", cls: "span4", text: "Training", required: true },
                        ]
                    },
                    {
                        text: "Position",
                        type: "controls",
                        items: [
                            { name: "DepartmentTraining", cls: "span2", placeholder: "Department", readonly: true },
                            { name: "PositionTraining", cls: "span2", placeholder: "Position", readonly: true },
                            { name: "GradeTraining", cls: "span2", placeholder: "Grade", readonly: true },
                        ]
                    },
                    {
                        text: "Pre Test",
                        type: "controls",
                        items: [
                            { name: "PreTest", cls: "span2", placeholder: "Pre Test", readonly: false },
                            { name: "PreTestAlt", cls: "span4", placeholder: "Pre Test Alternative", readonly: false, type: "select" },
                        ]
                    },
                    {
                        text: "Post Test",
                        type: "controls",
                        items: [
                            { name: "PostTest", cls: "span2", placeholder: "Post Test", readonly: false },
                            { name: "PostTestAlt", cls: "span4", placeholder: "Post Test Alternative", readonly: false, type: "select" },
                        ]
                    },
                    { type: "buttons", items: [{ name: "btnSaveTraining", text: "Save", icon: "icon-save" }, { name: "btnCancelTraining", text: "cancel", icon: "icon-undo" }] },
                ],
                columns: [
                    {
                        sTitle: "Action",
                        "mDataProp": "",
                        "sClass": "",
                        "sDefaultContent": "</i><i class='icon icon-trash'></i>",
                        sWidth: "100px"
                    },
                    { mData: "EmployeeID", sTitle: "NIK", sWidth: "100px" },
                    { mData: "EmployeeName", sTitle: "Name", sWidth: "200px" },
                    { mData: "TrainingName", sTitle: "Training Name", sWidth: "150px" },
                    {
                        mData: "TrainingDate", sTitle: "Training Date", sWidth: "100px",
                        mRender: function (data, type, full) {
                            if (widget.isNullOrEmpty(data) == false) {
                                return widget.toDateFormat(widget.cleanJsonDate(data));
                            }
                            return "-";
                        }
                    },
                    { mData: "PreTest", sTitle: "Pre", sWidth: "50px" },
                    { mData: "PostTest", sTitle: "Post", sWidth: "50px" },
                ],
                additionalParams: [
                    { name: "EmployeeID", element: "EmployeeID" },
                    { name: "Department", value: "SALES" },
                ],
            },
        ],
    }

    widget = new SimDms.Widget(options);
    var paramEvents = [
        {
            name: "TrainingDate",
            type: "input",
            eventType: "change",
            event: function (evt) {
                var url = "ab.api/Training/TrainingList";
                var params = {
                    EmployeeID: $("[name='EmployeeID']").val(),
                    TrainingDate: $("[name='TrainingDate']").val()
                };

                widget.post(url, params, function (result) {
                    if (widget.isNullOrEmpty(result.status)) {
                        console.log(result);
                        widget.setItems({
                            name: "TrainingCode",
                            type: "select",
                            data: result
                        });

                        url = "ab.api/Employee/GetDetailsEmployeePosition";
                        params = {
                            EmployeeID: $("[name='EmployeeID']").val(),
                            AssignDate: $("[name='TrainingDate']").val()
                        };

                        widget.post(url, params, function (result) {
                            if (widget.isNullOrEmpty(result.data) == false) {
                                $("[name='DepartmentTraining']").val(result.data.Department);
                                $("[name='PositionTraining']").val(result.data.Position);
                                $("[name='GradeTraining']").val(result.data.Grade);
                            }
                        });
                    }
                    else {
                        $("[name='TrainingDate']").val('');
                        alert(result.message);
                    }
                });
            }
        },
        {
            name: "btnAddTraining",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnAddTraining(evt);
            }
        },
        {
            name: "PositionTraining",
            type: "select",
            eventType: "change",
            event: function (evt) {
                var currentVal = widget.getValue({ name: "PositionTraining", type: "select" });
                var gradeElement = widget.getObject("GradeTraining", "select");
                if (currentVal == "S") {
                    gradeElement.attr("required", "required");
                }
                else {
                    gradeElement.removeAttr("required");
                    gradeElement.removeClass("error");
                    gradeElement.parent().children("label").parent().remove();
                }
            }
        },
        {
            name: "btnSaveTraining",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnSaveTraining(evt);
            }
        },
        {
            name: "btnCancelTraining",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnCancelTraining(evt);
            }
        },
        {
            name: "btnAddAchievement",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnAddAchievement(evt);
            }
        },
        {
            name: "btnSaveAchievement",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnSaveAchievement(evt);
            }
        },
        {
            name: "btnCancelAchievement",
            type: "button",
            eventType: "click",
            event: function (evt) {
                evt_btnCancelAchievement(evt);
            }
        },
        {
            name: "PositionAchievement",
            type: "select",
            eventType: "change",
            event: function (evt) {
                var currentVal = widget.getValue({ name: "PositionAchievement", type: "select" });
                var gradeElement = widget.getObject("GradeAchievement", "select");
                if (currentVal == "S") {
                    gradeElement.attr("required", "required");
                    widget.showInputElement({
                        name: "GradeAchievement",
                        type: "select",
                        visible: true,
                        type: "controls"
                    });
                }
                else {
                    widget.showInputElement({
                        name: "GradeAchievement",
                        type: "select",
                        visible: false,
                        type: "controls"
                    });
                    gradeElement.removeAttr("required");
                    gradeElement.removeClass("error");
                    gradeElement.parent().children("label").remove();
                }
            }
        },
        {
            name: "btnAddTraining",
            type: "button",
            eventType: "click",
            event: function (evt) {
                if (transactionStatus) {
                    $("[name='btnAddTraining']").hide();
                    $("#pnlTrainingHistory").slideDown();
                }
            }
        },
        {
            name: "btnSaveTraining",
            type: "button",
            eventType: "click",
            event: function (evt) {
                saveTraining(evt);
            }
        },
        {
            name: "btnCancelTraining",
            type: "button",
            eventType: "click",
            event: function (evt) {
                $("[name='btnAddTraining']").show();
                $("#pnlTrainingHistory").slideUp();
                widget.clearForm("formTraining");
                widget.clearValidation("formTraining");
            }
        },
        {
            name: "btnAddVehicle",
            type: "button",
            eventType: "click",
            event: function (evt) {
                if (transactionStatus) {
                    $("[name='btnAddVehicle']").hide();
                    $("#pnlVehicle").slideDown();
                }
            }
        },
        {
            name: "btnSaveVehicle",
            type: "button",
            eventType: "click",
            event: function (evt) {
                saveVehicle(evt);
            }
        },
        {
            name: "btnCancelVehicle",
            type: "button",
            eventType: "click",
            event: function (evt) {
                $("[name='btnAddVehicle']").show();
                $("#pnlVehicle").slideUp();
                widget.clearForm("formVehicle");
                widget.clearValidation("formVehicle");
            }
        },
        {
            name: "EmployeeID",
            type: "input",
            eventType: "blur",
            event: function (evt) {
                findEmployee();
            }
        },
        {
            name: "EmployeeID",
            type: "input",
            eventType: "keypress",
            event: function (evt) {
                if (evt.which == 13) {
                    findEmployee();
                }
            }
        },
        {
            name: "btnBrowse",
            type: "button",
            eventType: "click",
            event: function (evt) {
                initLookupEmployee(widget);
            }
        },
        {
            name: "btnProcess",
            type: "button",
            eventType: "click",
            event: function (evt) {
                widget.showToolbars(["btnSave", "btnCancel"]);
            }
        },
        {
            name: "btnClear",
            type: "button",
            eventType: "click",
            event: function (evt) {
                clearForm();
            }
        },
        {
            name: "btnSave",
            type: "button",
            eventType: "click",
            event: function (evt) {
                saveEmployee(evt);
            }
        },
        {
            name: "btnSaveNew",
            type: "button",
            eventType: "click",
            event: function (evt) {
                saveEmployee(evt, true);
            }
        },
        {
            name: "btnCancel",
            type: "button",
            eventType: "click",
            event: function (evt) {
                widget.showToolbars(["btnBrowse", "btnProcess", "btnClear"]);
            }
        },
        {
            name: "Village",
            type: "select",
            eventType: "change",
            event: function (evt) {
                var params = {
                    provinceCode: widget.getValue({ name: "Province", type: "select" }),
                    cityCode: widget.getValue({ name: "District", type: "select" }),
                    districtCode: widget.getValue({ name: "SubDistrict", type: "select" }),
                    villageCode: widget.getValue({ name: "Village", type: "select" })
                };

                widget.post("ab.api/Combo/ZipCode", params, function (result) {
                    widget.getObject("ZipCode").val(result);
                });
            }
        },
        {
            name: "PositionTraining",
            type: "select",
            eventType: "change",
            event: function (evt) {
                var currentVal = widget.getValue({ name: "PositionTraining", type: "select" });
                var gradeElement = widget.getObject("GradeTraining", "select");
                if (currentVal == "S") {
                    gradeElement.attr("required", "required");
                }
                else {
                    gradeElement.removeAttr("required");
                    gradeElement.removeClass("error");
                    gradeElement.parent().children("label").remove();
                }
            }
        },
    ];
    widget.setEventList(paramEvents);

    var paramsSelect = [
        {
            name: "DepartmentAchievement", url: "ab.api/Combo/Departments",
        },
        {
            name: "PositionAchievement", url: "ab.api/Combo/Positions",
            cascade: {
                name: "DepartmentAchievement",
            }
        },
        {
            name: "GradeAchievement", url: "ab.api/Combo/Grades",
            cascade: {
                name: "PositionAchievement",
                additionalParams: [],
                conditions: [
                    { name: "PositionAchievement", condition: "=='S'" }
                ]
            }
        },
        { name: "Department", url: "ab.api/Combo/Departments" },
        {
            name: "Position", url: "ab.api/Combo/Positions",
            cascade: {
                name: "Department"
            }
        },
        {
            name: "TeamLeader",
            url: "ab.api/Combo/TeamLeaders",
            cascade: {
                name: "Position",
                additionalParams: [ 
                    { name: "Department", source: "Department", type: "select" },
                    { name: "Position", source: "Position", type: "select" }
                ]
            }     
        },
        {
            name: "JoinBranch", url: "ab.api/Combo/Branch"
        },
        {
            name: "Rank", url: "ab.api/Combo/Ranks"
        },
        {
            name: "Grade", url: "ab.api/Combo/Grades",
            cascade: {
                name: "Position",
                conditions: [
                    { name: "Position", condition: "=='S'" }
                ]
            }
        },
        {
            name: "AdditionalJob1", url: "ab.api/Combo/Positions",
            cascade: {
                name: "Department"
            }
        },
        {
            name: "AdditionalJob2", url: "ab.api/Combo/Positions",
            cascade: {
                name: "Department"
            }
        },
        {
            name: "PersonnelStatus", url: "ab.api/Combo/PersonnelStatus"
        },
        {
            name: "Province", url: "ab.api/Combo/Provinces"
        },
        {
            name: "District", url: "ab.api/Combo/Cities",
            cascade: {
                name: "Province"
            }
        },
        {
            name: "SubDistrict", url: "ab.api/Combo/Districts",
            cascade: {
                name: "District"
            }
        },
        {
            name: "Village", url: "ab.api/Combo/Villages",
            cascade: {
                name: "SubDistrict"
            }
        },
        {
            name: "Gender", url: "ab.api/Combo/Genders"
        },
        {
            name: "MaritalStatus", url: "ab.api/Combo/MaritalStatus"
        },
        {
            name: "MaritalStatusCode", url: "ab.api/Combo/MaritalStatusDetails",
            cascade: {
                name: "MaritalStatus",
                conditions: [
                    { name: "MaritalStatus", condition: "=='K'" }
                ]
            }
        },
        {
            name: "UniformSize", url: "ab.api/Combo/UniformSizes"
        },
        {
            name: "ResignCategory", url: "ab.api/Combo/ResignCategories"
        },
        {
            name: "Religion", url: "ab.api/Combo/Religions"
        },
        {
            name: "UniformSizeAlt", url: "ab.api/Combo/UniformSizeAlts"
        },
        {
            name: "ShoesSize", url: "ab.api/Combo/ShoesSize"
        },
        {
            name: "BloodCode", url: "ab.api/Combo/BloodTypes"
        },
        {
            name: "FormalEducation", url: "ab.api/Combo/FormalEducations"
        },
        {
            name: "PreTestAlt", url: "ab.api/Combo/TrainingPreScoresAlternative"
        },
        {
            name: "PostTestAlt", url: "ab.api/Combo/TrainingPostScoresAlternative"
        },
        {
            name: "PositionTraining", url: "ab.api/Training/PositionList",
            cascade: {
                name: "DepartmentTraining",
                additionalParams: [
                    { name: "employeeID", source: "EmployeeID", type: "input" }
                ]
            }
        },
        {
            name: "GradeTraining", url: "ab.api/Combo/Grades",
            cascade: {
                name: "PositionTraining",
                additionalParams: []
            }
        },
        {
            name: "TrainingCode", url: "ab.api/Training/TrainingList",
            cascade: {
                name: "PositionTraining",
                additionalParams: [
                    { name: "EmployeeID", source: "EmployeeID", type: "input" },
                    { name: "Department", source: "DepartmentTraining", type: "select" },
                    { name: "Position", source: "PositionTraining", type: "select" },
                    { name: "Grade", source: "GradeTraining", type: "select" },
                ]
            }
        },
        {
            name: "TrainingCode", url: "ab.api/Training/TrainingList",
            cascade: {
                name: "GradeTraining",
                additionalParams: [
                    { name: "EmployeeID", source: "EmployeeID", type: "input" },
                    { name: "Department", source: "DepartmentTraining", type: "select" },
                    { name: "Position", source: "PositionTraining", type: "select" },
                    { name: "Grade", source: "GradeTraining", type: "select" },
                ]
            }
        },
    ];
    widget.setSelect(paramsSelect);

    widget.render(renderCallback);

    widget.lookup.onDblClick(function (e, data, name) {
        widget.populate(data, populateCallback(data, widget));
        widget.clearValidation();
        //checkPosition(data.EmployeeID);
        
        setTimeout(function () {
            reloadVehicleData(data.EmployeeID);
            reloadTrainingData();
            reloadSubordinateData();
            reloadAchievementData();
            reloadTrainingData();
        }, 1000);
        
        hideInputTab();
        enableEmployeeID(true);
        widget.lookup.hide();
        transactionStatus = true;

        if (name == "Employee" || name == "gridEmployeeID") {
            showJoinBranch(false);
        }
    });

    widget.onTabsChanged(function (obj, parent, name) { });
});



function renderCallback() {
    showResignDetails(false);
    validateResignDate();
}

function initLookupEmployee(widget) {
    widget.lookup.init({
        name: "Employee",
        title: "Employee List",
        source: "ab.api/grid/Employees",
        columns: [
            { mData: "EmployeeID", sTitle: "NIK", sWidth: "80px" },
            { mData: "EmployeeName", sTitle: "Name", sWidth: "250px" },
            {
                mData: "Department", sTitle: "Department", sWidth: "100px"
            },
            { mData: "Position", sTitle: "Position", sWidth: "100px" },
            {
                mData: "JoinDate", sTitle: "Join Date", sWidth: "100px",
                mRender: function (prefix, value, fullData) {
                    return widget.toDateFormat(widget.cleanJsonDate(fullData.JoinDate));
                }
            },
            {
                mData: "ResignDate", sTitle: "Resign Date", sWidth: "100px",
                mRender: function (prefix, value, fullData) {
                    if (widget.isNullOrEmpty(fullData.ResignDate) == false) {
                        return widget.toDateFormat(widget.cleanJsonDate(fullData.ResignDate));
                    }
                    else {
                        return "-";
                    }
                }
            },
            { mData: "Status", sTitle: "Status", sWidth: "100px" }
        ]
    });
    widget.lookup.show();
}

function populateCallback(data, widget) {
    if (widget.isNullOrEmpty(data.ResignDate) == false) {
        showResignDetails(true);
    }
    else {
        showResignDetails(false);
    }

    if (widget.isNullOrEmpty(data.Department) == false && widget.isNullOrEmpty(data.Position) == false) {
        enablePosition(false);
    }
    else {
        enablePosition(true);
    }

    if (widget.isNullOrEmpty(data.Position) == false) {
        widget.cascade({
            source: "Department",
            target: "Position",
            sourceValue: data.Department,
            targetValue: data.Position,
            url: "ab.api/Combo/Positions",
            additionalParams: [],
            enabled: false
        });
        widget.cascade({
            source: "Department",
            target: "AdditionalJob1",
            sourceValue: data.Department,
            targetValue: data.AdditionalJob1,
            url: "ab.api/Combo/Positions",
            additionalParams: [],
            enabled: true
        });
        widget.cascade({
            source: "Department",
            target: "AdditionalJob2",
            sourceValue: data.Department,
            targetValue: data.AdditionalJob2,
            url: "ab.api/Combo/Positions",
            additionalParams: [],
            enabled: true
        });
    }

    widget.cascade({
        source: "Position",
        target: "TeamLeader",
        sourceValue: data.Position,
        targetValue: data.TeamLeader,
        url: "ab.api/Combo/TeamLeaders",
        additionalParams: [
            { name: "Department", element: "Department", type: "select", value: data.Department },
            { name: "Position", element: "Position", type: "select", value: data.Position }
        ]
    });

    if (widget.isNullOrEmpty(data.AdditionalJob1) == false) {
        widget.cascade({
            source: "Department",
            target: "AdditionalJob1",
            sourceValue: data.Department,
            targetValue: data.AdditionalJob1,
            url: "ab.api/Combo/Positions",
            additionalParams: []
        });
    }

    if (widget.isNullOrEmpty(data.AdditionalJob2) == false) {
        widget.cascade({
            source: "Department",
            target: "AdditionalJob2",
            sourceValue: data.Department,
            targetValue: data.AdditionalJob2,
            url: "ab.api/Combo/Positions",
            additionalParams: []
        });
    }

    if (widget.isNullOrEmpty(data.Grade) == false) {
        widget.cascade({
            source: "Position",
            target: "Grade",
            sourceValue: data.Position,
            targetValue: data.Grade,
            url: "ab.api/Combo/Grades",
            additionalParams: [],
            enabled: false
        });
    }

    if (widget.isNullOrEmpty(data.District) == false) {
        widget.cascade({
            source: "Province",
            target: "District",
            sourceValue: data.Province,
            targetValue: data.District,
            url: "ab.api/Combo/Cities",
            additionalParams: []
        });
    }
   
    if (widget.isNullOrEmpty(data.SubDistrict) == false) {
        widget.cascade({
            source: "District",
            target: "SubDistrict",
            sourceValue: data.District,
            targetValue: data.SubDistrict,
            url: "ab.api/Combo/Districts",
            additionalParams: []
        });
    }

    if (widget.isNullOrEmpty(data.Village) == false) {
        widget.cascade({
            source: "SubDistrict",
            target: "Village",
            sourceValue: data.SubDistrict,
            targetValue: data.Village,
            url: "ab.api/Combo/Villages",
            additionalParams: []
        });
    }

    if (widget.isNullOrEmpty(data.MaritalStatusCode) == false) {
        widget.cascade({
            source: "MaritalStatus",
            target: "MaritalStatusCode",
            sourceValue: data.MaritalStatus,
            targetValue: data.MaritalStatusCode,
            url: "ab.api/Combo/MaritalStatusDetails",
            additionalParams: []
        });
    }

    widget.selects({
        name: "DepartmentTraining",
        source: "ab.api/Training/DepartmentList",
        additionalParams: [
            { name: "EmployeeID", element: "EmployeeID", type: "input", value: data.EmployeeID }
        ]
    });

    if (widget.isNullOrEmpty(data.SelfPhoto) == false) {
        $("#SelfPhoto").attr("src", SimDms.baseUrl + "ab.api/Employee/Photo/?fileID=" + data.SelfPhoto);
    }

    if (widget.isNullOrEmpty(data.IdentityCardPhoto) == false) {
        $("#IdentityCardPhoto").attr("src", SimDms.baseUrl + "ab.api/Employee/Photo/?fileID=" + data.IdentityCardPhoto);
    }

    widget.clearValidation();
}

function enableEmployeeID(isEnabled) {
    if (isEnabled) {
        widget.getObject("EmployeeID").removeAttr("readonly");
    }
    else {
        widget.getObject("EmployeeID").attr("readonly", "readonly");
    }

}

function enablePosition(enabled) {
    var departmentElement = widget.getObject("Department", "select");
    var positionElement = widget.getObject("Position", "select");
    var gradeElement = widget.getObject("Grade", "select");

    widget.enableElement([
        { name: "Department", type: "select", status: enabled },
        { name: "Position", type: "select", status: enabled },
        { name: "Grade", type: "select", status: enabled },
    ]);
}

function checkPosition(employeeID) {
    var url = "ab.api/Achievement/IsHasHistories";
    var params = {
        employeeID: employeeID
    };

    widget.post(url, params, function (result) {
        if (result.status == true) {
            enablePosition(false);
        }
        else {
            enablePosition(true);
        }
    });

    enablePosition(false);
}

function saveVehicle() {
    if (transactionStatus && widget.validate("formVehicle")) {
        var params = $("#pnlVehicle").serializeObject();
        params["EmployeeID"] = $("[name='EmployeeID']").val();
        var url = "ab.api/Vehicle/Save";

        widget.post(url, params, function (result) {
            if (result.status == true) {
                $("#pnlVehicle").slideUp();
                $("#btnAddVehicle").show();
                widget.clearForm("formVehicle");
                reloadVehicleData(params.EmployeeID);
            }
        });
    }
}

function deleteVehicle(evt, data) {
    if (confirm("Do you want to delete this data ?")) {
        var url = "ab.api/Vehicle/Delete";
        widget.post(url, data, function (result) {
            if (result.status) {
                reloadVehicleData();
            }
            else {
                alert(result.message);
            }
        });
    }
}

function saveTraining(evt) {
    if (transactionStatus && widget.validate("formTraining")) {
        var params = widget.getForms("formTraining");
        params["EmployeeID"] = widget.getValue({ name: "EmployeeID", type: "input" });
        var url = "ab.api/Training/Save";
        widget.post(url, params, function (result) {
            if (result.status) {
                $("[name='btnAddTraining']").show();
                $("#pnlTrainingHistory").slideUp();
                widget.clearForm("formTraining");
                reloadTrainingData();
            }
            else {
                alert(result.message);
            }
        });
    }
}

function deleteTraining(evt, data) {
    if (confirm("Do you want to delete this data ?")) {
        var params = {
            EmployeeID: data.EmployeeID,
            TrainingDate: widget.toDateFormat(widget.cleanJsonDate(data.TrainingDate))
        };
        var url = "ab.api/Training/Delete";
        widget.post(url, params, function (result) {
            reloadTrainingData();
        });
    }
}

function reloadSubordinateData() {
    widget.reloadGridData("tblSubordinate");
}

function reloadTrainingData(employeeID) {
    widget.reloadGridData("tblTrainingHistory");
}

function reloadVehicleData(employeeID) {
    widget.reloadGridData("tblVehicle");
}

function hideInputTab() {
    $("#pnlTrainingHistory").hide();
    $("#pnlVehicle").hide();

    $("#btnAddTraining").show();
    $("#btnAddVehicle").show();
}

function clearForm() {
    widget.clearForm();
    widget.clearValidation();
    enableEmployeeID(true);
    enablePosition(true);
    hideInputTab();
    reloadSubordinateData();
    reloadVehicleData();
    reloadTrainingData();
    reloadAchievementData();
    reloadTrainingData();
    transactionStatus = false;
    hideInputTab();
    showJoinBranch(true);
    showResignDetails(false);

    widget.clearForm("formVehicle");
    widget.clearValidation("formVehicle");
    widget.clearForm("formTraining");
    widget.clearValidation("formTraining");
    $("#SelfPhoto").attr("src", (SimDms.defaultEmployeePhoto || ""));
    $("#IdentityCardPhoto").attr("src", (SimDms.defaultIdentityCardPhoto || ""));
}

function findEmployee() {
    var url = "ab.api/Employee/Find";
    var params = {
        employeeID: widget.getValue({ name: "EmployeeID", type: "text" })
    };

    widget.post(url, params, function (result) {
        if (widget.isNullOrEmpty(result.data) == false) {
            widget.populate(result.data, populateCallback(result.data, widget));
            showJoinBranch(false);
        }
        else {
            var employeeID = $("[name='EmployeeID']").val();
            clearForm();
            $("[name='EmployeeID']").val(employeeID);
        }
    });
}

function saveEmployee(evt, isSaveNew) {
    if (widget.validate() == true) {
        widget.post("ab.api/Employee/Save", widget.getForms(), function (result) {
            if (result.status == true || result.status == "true") {
                enableEmployeeID(true);
                enablePosition(false);
                transactionStatus = true;
                showJoinBranch(false);

                if (isSaveNew) {
                    clearForm();
                }
            }
            else {
                alert(result.message);
            }
        });
    }
}

function showJoinBranch(isShowed) {
    if (isShowed) {
        $("[name='JoinDate']").attr("required", true);
        widget.showInputElement({
            name: "JoinBranch",
            type: "select",
            visible: true
        });
    }
    else {
        $("[name='JoinDate']").removeAttr("required");
        widget.showInputElement({
            name: "JoinBranch",
            type: "select",
            visible: false
        });
    }
}

function evt_SelfPhotoClick(evt) {
    if (transactionStatus) {
        var formName = "formSelfPhoto";
        var objectName = "SelfPhoto";

        if (isElementExist(formName) == false) {
            createAdditionalFormUpload(objectName);
        }

        var fileObject = $("#fileSelfPhoto");
        fileObject.off();
        fileObject.click();
        fileObject.on("change", function (evt) {
            var url = "ab.api/Employee/UploadPhoto";
            var params = {
                EmployeeID: $("[name='EmployeeID']").val(),
                PhotoType: "1"
            };

            $("#formSelfPhoto").ajaxSubmit({
                url: url,
                data: params,
                success: function (result) {
                    if (result.status) {
                        $("#SelfPhoto").attr("src", "ab.api/Employee/Photo/?fileID=" + result.data.fileID + "&");
                    }
                    else {
                        alert(result.message);
                    }
                }
            });
        });
    }
}

function evt_IdentityCardPhotoClick(evt) {
    if (transactionStatus) {
        var formName = "formIdentityCardPhoto";
        var objectName = "IdentityCardPhoto";

        if (isElementExist(formName) == false) {
            createAdditionalFormUpload(objectName);
        }

        var fileObject = $("#fileIdentityCardPhoto");
        fileObject.off();
        fileObject.click();
        fileObject.on("change", function (evt) {
            var url = "ab.api/Employee/UploadPhoto";
            var params = {
                EmployeeID: $("[name='EmployeeID']").val(),
                PhotoType: "2"
            };

            $("#formIdentityCardPhoto").ajaxSubmit({
                url: url,
                data: params,
                success: function (result) {
                    if (result.status) {
                        $("#IdentityCardPhoto").attr("src", "ab.api/Employee/Photo/?fileID=" + result.data.fileID + "&");
                    }
                    else {
                        alert(result.message);
                    }
                }
            });
        });
    }
}

function evt_ResignDate() {
    var dateValue = $("[name='ResignDate']").val();

    if (widget.isNullOrEmpty(dateValue) == false) {
        showResignDetails(true);
    }
    else {
        showResignDetails(false);
    }
}

function createAdditionalFormUpload(objectName) {
    var html = "";
    html += "<form style='display: none;' method='POST' name='form" + (objectName || "") + "' id='form" + (objectName || "") + "'  enctype='multipart/form-data'>";
    html += "<input type='file' name='file' id='file" + (objectName || "") + "' />";
    html += "</form>";

    $("body").append(html);
}

function isElementExist(elementName, elementID) {
    var isExist = false;
    
    var selectorName = "[name='" + (elementName || "") + "']";
    var selectorID = "#" + (elementID || "");

    if($(selectorName).length > 0 || $(selectorID).length > 0) {
        isExist = true;
    }

    return isExist;
}

function showResignDetails(resignDetailsStatus) {
    var resignCategory = $("[name='ResignCategory']");
    var resignDescription = $("[name='ResignDescription']");

    if (resignDetailsStatus != true) {
        resignCategory.val("");
        resignDescription.val("");

        resignCategory.removeAttr("required");
        resignDescription.removeAttr("required");
    }
    else {
        resignCategory.attr("required", true);
        resignDescription.attr("required", true);
    }

    widget.showItem([
        {
            name: "ResignCategory",
            isVisible: resignDetailsStatus
        },
        {
            name: "ResignDescription",
            isVisible: resignDetailsStatus
        }
    ]);
}

function validateResignDate() {
    setInterval(evt_ResignDate, 1000);
}





//ACHIEVEMENT AREA

function evt_btnAddAchievement(evt) {
    if (transactionStatus) {
        $("#pnlEmployeeAchievement").slideDown();
        widget.showInputElement({
            name: "GradeAchievement",
            type: "select",
            visible: true
        });
        validateJoinDateEmployeeAchievement(true);
    }
}

function validateJoinDateEmployeeAchievement(hideAddAchievement) {
    var url = "ab.api/Employee/CheckJoinDate";
    var params = { EmployeeID: $("#EmployeeID").val() };

    widget.post(url, params, function (result) {
        var panelAchievementVisibility = $("#pnlEmployeeAchievement").css("display");

        if (panelAchievementVisibility != "none") {
            $("[name='btnAddAchievement']").hide();
        }
        else {
            $("[name='btnAddAchievement']").show();
        }

        widget.changeSwitchValue({
            panel: "pnlEmployeeAchievement",
            name: "IsJoinDate",
            value: false
        });

        if (widget.isNullOrEmpty(result.data) == false) {
            if (widget.isNullOrEmpty(result.data.HasJoinDateInAchievement) == false) {
                var panelJoinDate = $("#IsJoinDateN").parent().parent().parent();
                if (result.data.HasJoinDateInAchievement == true) {
                    panelJoinDate.hide();
                }
                else {
                    panelJoinDate.show();
                }
            }
            else {
                $("#IsJoinDateN").parent("div").show();
            }

            variables["DeleteAchievementStatus"] == false;

            $("#IsJoinDateN, #IsJoinDateY").on("click", function (event) {
                var _this = this;
                setTimeout(function () {
                    $("[name='AssignDate']").attr("disabled", true);
                    var isJoinDate = $(_this).attr("value");

                    if ($(_this).attr("value") == "true") {
                        if (widget.isNullOrEmpty(result.data.JoinDate) == false) {
                            $("[name='AssignDate']").val(widget.toDateFormat(widget.cleanJsonDate(result.data.JoinDate)));
                        }
                    }
                    else {
                        $("[name='AssignDate']").val('');
                        $("[name='AssignDate']").removeAttr("disabled");
                    }
                }, 250);
            });
        }
    });
}

function evt_btnSaveAchievement(evt) {
    if (transactionStatus && widget.validate("formAchievement")) {
        var params = widget.getForms("formAchievement");
        params["EmployeeID"] = widget.getValue({ name: "EmployeeID", type: "input" });
        var url = "ab.api/Achievement/Save";
        widget.post(url, params, function (result) {
            if (result.status) {
                $("[name='btnAddAchievement']").show();
                $("#pnlEmployeeAchievement").slideUp();
                widget.clearForm("formAchievement");
                updateEmployeeForm(params["EmployeeID"]);
                reloadAchievementData();
                $("[name='AssignDate']").removeAttr("disabled");
                $("[name='AssignDate']").val('');
            }
            else {
                alert(result.message);
            }
        });
    }
}

function evt_btnCancelAchievement(evt) {
    $("[name='btnAddAchievement']").show();
    $("#pnlEmployeeAchievement").slideUp();
    widget.clearForm("formAchievement");
    widget.clearValidation("formAchievement");
    $("[name='AssignDate']").val('');
    $("[name='AssignDate']").removeAttr("disabled");
}

function reloadAchievementData() {
    setTimeout(function () {
        widget.reloadGridData("tblEmployeeAchievement");
    }, 1000);
}

function deleteAchievement(evt, data) {
    if (confirm("Do you want to delete this data ?")) {
        variables["DeleteAchievementStatus"] = false;
        var params = $.extend(data, {
            AssignDate: widget.toDateFormat(widget.cleanJsonDate(data.AssignDate))
        });

        var url = "ab.api/Achievement/Delete";
        widget.post(url, params, function (result) {
            if (result.status) {
                //clearForm();
                reloadAchievementData();
                updateEmployeeForm(data.EmployeeID);
                variables["DeleteAchievementStatus"] == true;
                validateJoinDateEmployeeAchievement(true);
            }
            else {
                alert(result.message);
            }
            $("[name='btnAddAchievement']").show();
        });
    }
}

function updateEmployeeForm(employeeID) {
    var url = "ab.api/Achievement/UpdatedAchievement";
    var params = {
        EmployeeID: employeeID
    };

    widget.post(url, params, function (result) {
        if (result.status) {
            result.data["JoinDate"] = widget.toDateFormat(widget.cleanJsonDate(result.data.JoinDate));
            widget.populate(result.data);
        }
    });
}










function evt_btnAddTraining(evt) {
    if (transactionStatus) {
        $("[name='btnAddTraining']").hide();
        $("#pnlTrainingHistory").slideDown();
    }
}

function evt_btnSaveTraining(evt) {
    if (transactionStatus) {
        //if (transactionStatus && widget.validate("formTraining")) {
        var params = widget.getForms("formTraining");
        params["EmployeeID"] = widget.getValue({ name: "EmployeeID", type: "input" });
        params["TrainingCode"] = widget.getValue({ name: "TrainingCode", type: "select" });
        params["TrainingDate"] = widget.getValue({ name: "TrainingDate", type: "input" });
        params["PreTest"] = widget.getValue({ name: "PreTest", type: "input" });
        params["PreTestAlt"] = widget.getValue({ name: "PreTestAlt", type: "input" });
        params["PostTest"] = widget.getValue({ name: "PostTest", type: "input" });
        params["PostTestAlt"] = widget.getValue({ name: "PostTestAlt", type: "input" });


        var url = "ab.api/Training/Save";
        widget.post(url, params, function (result) {
            console.log(result);
            if (result.status) {
                $("[name='btnAddTraining']").show();
                $("#pnlTrainingHistory").slideUp();
                widget.clearForm("formTraining");
                reloadTrainingData();
            }
            else {
                alert(result.message);
            }
        });
    }
}

function evt_btnCancelTraining(evt) {
    $("[name='btnAddTraining']").show();
    $("#pnlTrainingHistory").slideUp();
    widget.clearForm("formTraining");
    widget.clearValidation("formTraining");
}

function reloadTrainingData() {
    setTimeout(function () {
        widget.reloadGridData("tblTrainingHistory");
    }, 1000);
}

function saveTraining(evt) {
    if (transactionStatus && widget.validate("formTraining")) {
        var params = widget.getForms("formTraining");
        params["EmployeeID"] = widget.getValue({ name: "EmployeeID", type: "input" });
        var url = "ab.api/Training/Save";
        widget.post(url, params, function (result) {
            if (result.status) {
                $("[name='btnAddTraining']").show();
                $("#pnlTrainingHistory").slideUp();
                widget.clearForm("formTraining");
                reloadTrainingData();
            }
            else {
                alert(result.message);
            }
        });
    }
}

function deleteTraining(evt, data) {
    if (confirm("Do you want to delete this data ?")) {
        var params = {
            EmployeeID: data.EmployeeID,
            TrainingDate: widget.toDateFormat(widget.cleanJsonDate(data.TrainingDate))
        };
        var url = "ab.api/Training/Delete";
        widget.post(url, params, function (result) {
            reloadTrainingData();
            widget.reloadGridData("tblTrainingHistory");
        });
    }
}

angular.module('starter.services', ['LocalStorageModule'])

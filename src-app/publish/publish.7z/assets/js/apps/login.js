﻿var login = function () {
    var page = 'login';


}
#!/bin/bash
zip -r BugTracker.NET.xpi install.rdf chrome.manifest chrome defaults

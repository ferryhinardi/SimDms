pref("extensions.btnet.url", "http://127.0.0.1/btnet");
pref("extensions.btnet.imageSize", 800);                
pref("extensions.btnet.projectNumber", 0);  

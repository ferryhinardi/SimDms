﻿exports.start = function () {
	require("../../lib/JobBkf").service();
}
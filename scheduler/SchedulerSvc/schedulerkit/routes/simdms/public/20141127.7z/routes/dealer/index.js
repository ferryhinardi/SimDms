﻿exports.start = function () {
	require("../../lib/JobManager").service();
}